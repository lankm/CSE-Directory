#ifndef PROBLEM_1_
#define PROBLEM_1_

#include <stdio.h>
#include <stdlib.h>
#include "bt_utils.h"
#include "vehicle.h"

#define BUF_SIZE 64
#define CMDS 3

void load_vehicles(FILE *fp, BTNode **root);

#endif
