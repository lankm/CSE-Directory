#ifndef PROBLEM_1_
#define PROBLEM_1_

void a();
void b();
void c();
void d();
void e();
void f();
void g();
void h();
void i();
void j();

#endif