#ifndef DYNAMIC_ARR
#define DYNAMIC_ARR

typedef struct {
    double *data;
    int size;
} dynamic_array;

#endif
