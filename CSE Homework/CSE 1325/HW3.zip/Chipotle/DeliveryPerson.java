import deliverystuff.Student;

public class DeliveryPerson extends Student {
    public DeliveryPerson(String name) {
        this.name=name;
    }
}
