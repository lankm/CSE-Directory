package chilistuff;

public class Customer extends Person {
    public Customer(String name) {
        super(name);
    }
}
