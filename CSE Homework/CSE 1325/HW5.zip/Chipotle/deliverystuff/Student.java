package deliverystuff;

public class Student {
    public String name;
}
