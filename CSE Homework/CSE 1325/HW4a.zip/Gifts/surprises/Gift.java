package surprises;

interface Gift { 
    public void surpriseRecipient(String name); 
 } 
