import surprises.*;

public class GiftsMain 
{   
   public static void main(String args[]){    
      FlowerArrangement f1=new FlowerArrangement(); 
      f1.surpriseRecipient("Miguel"); 
 
      ChocolateBox c1=new ChocolateBox(); 
      c1.surpriseRecipient("Cole"); 
   }   
} 