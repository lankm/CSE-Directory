package watches;

public interface Timeable {
    public String getTime();    //In this universe time does not pass
    public void setTime(String time);
}
