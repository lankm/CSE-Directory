package watches;

public interface Repairable {
    public void repair();
    public void break_obj();
}
