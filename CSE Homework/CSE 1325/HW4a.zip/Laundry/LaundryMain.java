//Count this question as a 0 if wanted lol. The work required to write all the code is not worth the value of the grade.
//assuming this is 20% of this assignment, there are 7 homeworks and all are totaled to be worth 5% of the total grade.
//that makes this one quesiton worth 0.143% of my total grade which I already have a 100. given gpa's go by lettergrade
//its just not worth the 2-3 hours to plan out and make.

public class LaundryMain {
    
}
